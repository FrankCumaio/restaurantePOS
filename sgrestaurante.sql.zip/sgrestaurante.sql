-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 02-Nov-2015 às 16:25
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sgrestaurante`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoriapratos`
--

CREATE TABLE IF NOT EXISTS `categoriapratos` (
  `idCategoriaPratos` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  PRIMARY KEY (`idCategoriaPratos`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `categoriapratos`
--

INSERT INTO `categoriapratos` (`idCategoriaPratos`, `nome`) VALUES
(5, 'Saladas'),
(6, 'Entradas'),
(7, 'Bebidas'),
(8, 'Sopas'),
(9, 'Burguers');

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoriaproduto`
--

CREATE TABLE IF NOT EXISTS `categoriaproduto` (
  `idCategoriaProduto` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  PRIMARY KEY (`idCategoriaProduto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `categoriaproduto`
--

INSERT INTO `categoriaproduto` (`idCategoriaProduto`, `nome`) VALUES
(4, 'Frutas'),
(5, 'Legumes'),
(6, 'Liquidos'),
(7, 'produtos de limpeza'),
(8, 'Cafe'),
(9, 'Carne'),
(10, 'Mariscos'),
(11, 'cereais');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `sexo` varchar(45) NOT NULL,
  `Contacto_idContacto` int(11) NOT NULL,
  `Identificacao_idIdentificacao` int(11) NOT NULL,
  `Morada_idMorada` int(11) NOT NULL,
  PRIMARY KEY (`idCliente`),
  KEY `fk_Cliente_Contacto1_idx` (`Contacto_idContacto`),
  KEY `fk_Cliente_Identificacao1_idx` (`Identificacao_idIdentificacao`),
  KEY `fk_Cliente_Morada1_idx` (`Morada_idMorada`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nome`, `sexo`, `Contacto_idContacto`, `Identificacao_idIdentificacao`, `Morada_idMorada`) VALUES
(2, 'Frank Cumaio', 'Masculino', 8, 5, 8),
(3, 'Inercio Belton', 'Masculino', 48, 9, 48),
(4, 'Rogerio', 'Masculino', 58, 10, 58);

-- --------------------------------------------------------

--
-- Estrutura da tabela `contacliente`
--

CREATE TABLE IF NOT EXISTS `contacliente` (
  `idcontaCliente` int(11) NOT NULL AUTO_INCREMENT,
  `produto` varchar(45) DEFAULT NULL,
  `quantidade` double DEFAULT NULL,
  `preco` double DEFAULT NULL,
  `grupoProduto` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idcontaCliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Extraindo dados da tabela `contacliente`
--

INSERT INTO `contacliente` (`idcontaCliente`, `produto`, `quantidade`, `preco`, `grupoProduto`, `data`, `estado`) VALUES
(1, 'Salada de legume', 1, 1, 1, '2015-10-11', NULL),
(2, 'Sprite', 2, 2, 1, '2015-10-11', NULL),
(3, 'Fanta', 1, 1, 1, '2015-10-11', NULL),
(4, 'Coca cola', 1, 1, 1, '2015-10-11', NULL),
(5, 'Humburguer especial', 1, 1, 1, '2015-10-11', NULL),
(6, 'Salada de legumes', 1, 150, 2, '2015-10-17', 'pendente'),
(7, 'Salada de legumes', 1, 150, 3, '2015-10-17', 'pendente'),
(8, 'Sparleta', 1, 35, 3, '2015-10-17', 'pendente'),
(9, 'Sparleta', 1, 35, 3, '2015-10-17', 'pendente'),
(10, 'Salada de legumes', 1, 150, 4, '2015-10-17', 'pendente'),
(11, 'Sparleta', 1, 35, 4, '2015-10-17', 'pendente'),
(12, 'Sparleta', 1, 35, 4, '2015-10-17', 'pendente'),
(13, 'Blue', 1, 35, 4, '2015-10-17', 'pendente'),
(14, 'Salada de legumes', 1, 150, 4, '2015-10-17', 'pendente'),
(15, 'Salada de legumes', 1, 150, 5, '2015-10-19', 'pendente'),
(16, 'Pepsi', 1, 150, 5, '2015-10-19', 'pendente');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contacliente_has_cliente`
--

CREATE TABLE IF NOT EXISTS `contacliente_has_cliente` (
  `contaCliente_idcontaCliente` int(11) NOT NULL,
  `cliente_idCliente` int(11) NOT NULL,
  PRIMARY KEY (`contaCliente_idcontaCliente`,`cliente_idCliente`),
  KEY `fk_contaCliente_has_cliente_cliente1_idx` (`cliente_idCliente`),
  KEY `fk_contaCliente_has_cliente_contaCliente1_idx` (`contaCliente_idcontaCliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `contacliente_has_cliente`
--

INSERT INTO `contacliente_has_cliente` (`contaCliente_idcontaCliente`, `cliente_idCliente`) VALUES
(1, 2),
(2, 2),
(3, 2),
(4, 2),
(5, 2),
(7, 2),
(8, 2),
(9, 2),
(10, 2),
(11, 2),
(12, 2),
(13, 2),
(14, 2),
(6, 3),
(15, 3),
(16, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `contacto`
--

CREATE TABLE IF NOT EXISTS `contacto` (
  `idContacto` int(11) NOT NULL AUTO_INCREMENT,
  `telefone` varchar(45) DEFAULT NULL,
  `celular` varchar(45) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idContacto`),
  UNIQUE KEY `idContacto_UNIQUE` (`idContacto`),
  UNIQUE KEY `celular_UNIQUE` (`celular`),
  UNIQUE KEY `telefone_UNIQUE` (`telefone`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
-- Extraindo dados da tabela `contacto`
--

INSERT INTO `contacto` (`idContacto`, `telefone`, `celular`, `email`) VALUES
(5, '798645', '754789', 'jhnk@gmail.com'),
(6, '84200561', '789455', 'inercio@gmail.com'),
(7, '978465', '7854', 'dsfafasad'),
(8, '984651', '9846548', 'ythfygjjzhxn'),
(9, '21565851', '845644132', 'legumesltd@gmail.com'),
(10, '68452', '78541', 'zdxczxc'),
(11, '645326', '98654', 'zxjhgkjz'),
(22, '215684218', '84568459f', 'talhoM@gmail.com'),
(31, '8465', '79845', 'sdiuashkd'),
(33, '7946', '98764', 'cgvhbjnm'),
(34, '978456', '978654', 'udjsgchkjsD'),
(40, '854', '874654', 'fhcgvj'),
(47, '541', '2423', 'wassfd'),
(48, '7845', '789654', 'inercio28@gmail.com'),
(53, '789654321', '789465', 'fyghj'),
(54, '98645', '978645', 'ygjknhui'),
(55, '98745', '986745', 'gjj'),
(56, '878787', '95655', 'tuygkj'),
(57, '8445', '8452', 'ghjk'),
(58, '84956595', '8298645', 'rojas@gmail.com'),
(59, '8294865146', '864654854', 'bilas@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `formaspagamento`
--

CREATE TABLE IF NOT EXISTS `formaspagamento` (
  `idFormasPagamento` int(11) NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(45) NOT NULL,
  `TaxaDeJuros` double NOT NULL,
  PRIMARY KEY (`idFormasPagamento`),
  UNIQUE KEY `Tipo_UNIQUE` (`Tipo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `formaspagamento`
--

INSERT INTO `formaspagamento` (`idFormasPagamento`, `Tipo`, `TaxaDeJuros`) VALUES
(1, 'Dinheiro', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedores`
--

CREATE TABLE IF NOT EXISTS `fornecedores` (
  `idFornecedores` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `nrRegisto` varchar(255) NOT NULL,
  `tipoProduto` varchar(255) NOT NULL,
  `observacoes` varchar(45) DEFAULT NULL,
  `distancia` double DEFAULT NULL,
  `unidadeMedida` varchar(45) DEFAULT NULL,
  `Contacto_idContacto` int(11) NOT NULL,
  `Morada_idMorada` int(11) NOT NULL,
  `CategoriaProduto_idCategoriaProduto` int(11) NOT NULL,
  PRIMARY KEY (`idFornecedores`),
  KEY `fk_Fornecedores_Contacto1_idx` (`Contacto_idContacto`),
  KEY `fk_Fornecedores_Morada1_idx` (`Morada_idMorada`),
  KEY `fk_Fornecedores_CategoriaProduto1_idx` (`CategoriaProduto_idCategoriaProduto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `fornecedores`
--

INSERT INTO `fornecedores` (`idFornecedores`, `nome`, `nrRegisto`, `tipoProduto`, `observacoes`, `distancia`, `unidadeMedida`, `Contacto_idContacto`, `Morada_idMorada`, `CategoriaProduto_idCategoriaProduto`) VALUES
(3, 'Fornecedor de fruta', '110005458', 'Frutas', '', 320, 'Kilometros', 7, 7, 4),
(4, 'Legumes frescos Ltd', '6854100056', 'Legumes', '', 60, 'Kilometros', 9, 9, 5),
(5, 'Talho Matola B', '112185612', 'Carne', '', 50, 'metros', 22, 22, 9),
(6, 'Peixe da mama', '111564', 'Mariscos', '', 500, 'metros', 31, 31, 10),
(7, 'ugh', '68465', 'Frutas', NULL, NULL, NULL, 40, 40, 4),
(8, 'fsfd', '2343', 'Frutas', 'jhk', 20, 'metros', 47, 47, 4),
(10, 'ujhg', '864564', 'Frutas', 'observacoes', 0, 'metros', 54, 54, 4),
(11, 'uyjgtdh', 'tgiguh', 'cereais', 'observacoes', 0, 'metros', 55, 55, 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

CREATE TABLE IF NOT EXISTS `funcionarios` (
  `idFuncionario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `sexo` varchar(45) NOT NULL,
  `dataNascimento` date NOT NULL,
  `cargo` varchar(255) NOT NULL,
  `salario` double(10,2) NOT NULL,
  `dataIngresso` date NOT NULL,
  `Contacto_idContacto` int(11) NOT NULL,
  `Identificacao_idIdentificacao` int(11) NOT NULL,
  `Morada_idMorada` int(11) NOT NULL,
  PRIMARY KEY (`idFuncionario`),
  KEY `fk_Funcionarios_Contacto1_idx` (`Contacto_idContacto`),
  KEY `fk_Funcionarios_Identificacao1_idx` (`Identificacao_idIdentificacao`),
  KEY `fk_Funcionarios_Morada1_idx` (`Morada_idMorada`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `funcionarios`
--

INSERT INTO `funcionarios` (`idFuncionario`, `nome`, `sexo`, `dataNascimento`, `cargo`, `salario`, `dataIngresso`, `Contacto_idContacto`, `Identificacao_idIdentificacao`, `Morada_idMorada`) VALUES
(2, 'Mr. Belton ', 'Masculino', '1996-03-11', 'Garcon', 5000.00, '2014-09-09', 5, 3, 5),
(3, 'Inercio Belton', 'Masculino', '1996-03-11', 'Gerente', 15000.00, '2012-09-10', 6, 4, 6),
(4, 'Bila', 'Masculino', '1983-11-14', 'Cozinheiro', 5000.00, '2013-11-12', 59, 11, 59);

-- --------------------------------------------------------

--
-- Estrutura da tabela `identificacao`
--

CREATE TABLE IF NOT EXISTS `identificacao` (
  `idIdentificacao` int(11) NOT NULL AUTO_INCREMENT,
  `tipoIdentificacao` varchar(255) NOT NULL,
  `numeroIdentificacao` varchar(255) NOT NULL,
  `dataValidade` date NOT NULL,
  PRIMARY KEY (`idIdentificacao`),
  UNIQUE KEY `idIdentificacao_UNIQUE` (`idIdentificacao`),
  UNIQUE KEY `numeroIdentificacao_UNIQUE` (`numeroIdentificacao`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `identificacao`
--

INSERT INTO `identificacao` (`idIdentificacao`, `tipoIdentificacao`, `numeroIdentificacao`, `dataValidade`) VALUES
(3, 'BI', '8645', '2016-09-22'),
(4, 'BI', '8645554F', '2015-09-23'),
(5, 'BI', '9846579645G', '2016-09-21'),
(8, 'BI', '84651', '2015-10-11'),
(9, 'BI', '8645452f', '2015-10-15'),
(10, 'BI', '98654865418K', '2015-11-02'),
(11, 'BI', '9874654845634J', '2015-11-18');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ingredientes`
--

CREATE TABLE IF NOT EXISTS `ingredientes` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `ID` int(11) NOT NULL,
  `produto` varchar(45) NOT NULL,
  `quantidade` double NOT NULL,
  `preco` double NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=146 ;

--
-- Extraindo dados da tabela `ingredientes`
--

INSERT INTO `ingredientes` (`codigo`, `ID`, `produto`, `quantidade`, `preco`) VALUES
(81, 7, 'banana', 15, 15),
(82, 8, 'banana', 12, 15),
(83, 8, 'laranja', 5, 15),
(85, 9, 'banana', 5, 15),
(87, 9, 'ananas', 5, 15),
(90, 10, 'laranja', 5, 15),
(91, 11, 'banana', 12, 15),
(92, 11, 'laranja', 12, 15),
(95, 12, 'banana', 5, 15),
(96, 13, 'cenoura', 2, 20),
(97, 14, 'cenoura', 2, 20),
(98, 15, 'ananas', 3, 15),
(101, 16, 'carne de vaca', 1, 150),
(102, 16, 'Cenoura', 1, 20),
(103, 17, 'carne de vaca', 2, 150),
(104, 18, 'carne de vaca', 1, 150),
(107, 19, 'banana', 2, 15),
(108, 19, 'laranja', 2, 15),
(109, 19, 'ananas', 2, 15),
(112, 21, 'Cenoura', 10, 20),
(113, 22, 'banana', 30, 15),
(114, 22, 'Cenoura', 30, 20),
(115, 23, 'Cenoura', 5, 20),
(120, 20, 'Cenoura', 50, 20),
(121, 21, 'laranja', 90, 15),
(122, 22, 'banana', 20, 15),
(123, 22, 'ananas', 20, 15),
(124, 23, 'carne de vaca', 10, 150),
(125, 23, 'banana', 10, 15),
(126, 24, 'banana', 10, 15),
(127, 24, 'carne de vaca', 10, 150),
(128, 25, 'banana', 0, 15),
(129, 25, 'banana', 0, 15),
(130, 26, 'banana', 0, 15),
(131, 27, 'banana', 10, 15),
(133, 28, 'banana', 20, 15),
(134, 28, 'ananas', 20, 15),
(135, 28, 'laranja', 20, 20),
(136, 29, 'banana', 10, 15),
(137, 29, 'ananas', 10, 15),
(138, 29, 'laranja', 10, 20),
(139, 30, 'banana', 10, 15),
(140, 30, 'banana', 10, 15),
(142, 31, 'carne de vaca', 5, 150),
(143, 31, 'banana', 10, 15),
(144, 32, 'banana', 10, 15),
(145, 32, 'ananas', 10, 15);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ingredientes_aux`
--

CREATE TABLE IF NOT EXISTS `ingredientes_aux` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `ID` int(11) NOT NULL,
  `produto` varchar(45) NOT NULL,
  `quantidade` double NOT NULL,
  `preco` double NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mesas`
--

CREATE TABLE IF NOT EXISTS `mesas` (
  `idMesas` int(11) NOT NULL AUTO_INCREMENT,
  `nomeMesa` varchar(45) NOT NULL,
  `numeroLugares` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `estado` varchar(45) NOT NULL,
  PRIMARY KEY (`idMesas`),
  UNIQUE KEY `numeroMesa_UNIQUE` (`nomeMesa`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `mesas`
--

INSERT INTO `mesas` (`idMesas`, `nomeMesa`, `numeroLugares`, `descricao`, `estado`) VALUES
(4, '1', 5, '', 'Ocupada'),
(6, '3', 4, '', 'Ocupada'),
(7, '4', 3, '', 'Ocupada'),
(8, '5', 6, '', 'Livre'),
(10, '6', 4, '', 'Livre'),
(11, 'Frank Cumaio', 4, '', 'Ocupada');

-- --------------------------------------------------------

--
-- Estrutura da tabela `morada`
--

CREATE TABLE IF NOT EXISTS `morada` (
  `idMorada` int(11) NOT NULL AUTO_INCREMENT,
  `AvRua` varchar(255) DEFAULT NULL,
  `Cidade` varchar(255) NOT NULL,
  `Bairro` varchar(255) NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`idMorada`),
  UNIQUE KEY `idMorada_UNIQUE` (`idMorada`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
-- Extraindo dados da tabela `morada`
--

INSERT INTO `morada` (`idMorada`, `AvRua`, `Cidade`, `Bairro`, `numero`) VALUES
(5, 'ijkn', 'Maputo', 'Mahotas', 456),
(6, 'jhnkm,', 'Maputo', 'Mahotas', 104),
(7, 'jnjn', 'Matola', 'Liberdade', 1110),
(8, 'fhgjk', 'Matola A', 'Fomento A', 9845),
(9, 'uytggjh', 'Matola', 'Liberdade', 654845),
(10, 'dzfxv', 'asfzcx', 'ersdgz', 45345),
(11, 'zxcsdz\\c', 'j,zxnc', 'zxchbk', 6546),
(12, 'zcxhbmn', 'czxmzx', 'zcxkjn,', 65312),
(13, 'ooo', 'Matola', 'Fomento', 132165),
(14, 'ooo', 'Matola', 'Fomento', 132165),
(15, 'ooo', 'Matola', 'Fomento', 132165),
(16, 'ooo', 'Matola', 'Fomento', 132165),
(17, 'ooo', 'Matola', 'Fomento', 132165),
(18, 'ooo', 'Matola', 'Fomento', 132165),
(19, 'ooo', 'Matola', 'Fomento B', 132165),
(20, 'ooo', 'Matola B', 'Fomento B', 132165),
(21, 'ooo', 'Matola B', 'Fomento B', 132165),
(22, 'ooo', 'Matola B', 'Fomento B', 132165),
(23, 'sadas', 'Maputo', 'sadsa', 545445),
(24, 'sadas', 'Maputo', 'sadsa', 545445),
(25, 'sadas', 'Maputo', 'sadsa', 5454458),
(26, 'sadas', 'Maputo', 'sadsa', 5454458),
(27, 'sdflkcxm', 'Maputo', 'sdlkjsj', 97845),
(28, 'sdflkcxm', 'Maputo', 'sdlkjsj', 97845),
(29, 'sdflkcxm', 'Maputo', 'sdlkjsj', 97845),
(30, '4865', 'Maputo', 'jjj', 845231),
(31, 'kjasdn', 'Maputol', 'adjdlk', 965465),
(32, 'tfcgvjhbj', 'gcvbn', 'etrdyfgv', 49865),
(33, 'ughkjnl', 'tuygh', 'hvbnm', 465556),
(34, 'dgfcvjh', 'hjvbv', '897645', 874645),
(35, 'dgfcvjh', 'hjvbv', '897645', 874645),
(36, 'ghhjkm', 'Maputo', 'fasd', 54465),
(37, 'ghhjkm', 'Maputo', 'fasd', 54465),
(38, 'gvjbnm', 'vbnm', 'dxtfcgv', 978465),
(39, 'hgj,', 'hgkj,hn', 'iuhkh', 8798),
(40, 'ytfgh', 'uyggyug', 'iugiu', 54564),
(41, 'hgcvjh', 'jhvjhgh', 'ujvhb', 8645),
(42, 'jhgnbm', 'vkhm', 'jgjhb', 5745),
(43, 'hghfjh', 'uyguigh', 'hghiuh', 978676),
(44, 'ghvhjg', 'ghjkj', 'jhgjhv', 7654),
(45, 'sdfgd', 'wesfd', 'wes', 23445),
(46, 'qwrsr', 'wqer', 'ASDS', 23145),
(47, 'qwrsr', 'wqer', 'ASDS', 23145),
(48, 'jh,n', 'Maputo', 'Mahotas', 99856),
(49, 'jhbm', 'ikjb,', 'hgvb', 4564),
(50, 'ugjhbkm', 'fgchgvjbnm', 'yfghn', 685741),
(51, 'uihjkl', '7hjn', 'utfguyghjk', 745634),
(52, 'yfghj', 'yghu', 'cgvhbjn', 7459),
(53, 'yfghj', 'yghu', 'cgvhbjn', 7459),
(54, 'ujgkjlk', 'rydtfuyghkj', 'jhjkm', 76854),
(55, 'fjghbjk', 'ihkjlkjl', 'ygfjh', 986465),
(56, 'yuhjkn', 'ikjh', 'ughj', 75454),
(57, 'ihkn', 'gvjhbkjnl', 'cdgfhcjvh', 655655),
(58, 'etdrfugyh', 'Maputo', 'Polana ', 7896454),
(59, 'fcvjhbk', 'Maputo', 'Maxaquene', 8964654);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos`
--

CREATE TABLE IF NOT EXISTS `pedidos` (
  `idpedidos` int(11) NOT NULL,
  `ncliente` int(11) NOT NULL,
  `designacao` varchar(45) NOT NULL,
  `quant` int(11) NOT NULL,
  `preco` double NOT NULL,
  `horaPedido` varchar(45) NOT NULL,
  `grupoPedidos` int(11) DEFAULT NULL,
  `estado` varchar(45) NOT NULL,
  PRIMARY KEY (`idpedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pedidos`
--

INSERT INTO `pedidos` (`idpedidos`, `ncliente`, `designacao`, `quant`, `preco`, `horaPedido`, `grupoPedidos`, `estado`) VALUES
(14, 1, 'Salada de legumes', 1, 150, '15:00', 13, 'Pendente'),
(15, 2, 'Pepsi', 1, 150, '15:00', 13, 'Pendente'),
(16, 2, 'Coca Cola', 1, 35, '15:00', 13, 'Pendente'),
(17, 3, 'Salada de legumes', 1, 150, '15:00', 13, 'Pendente');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos_has_mesas`
--

CREATE TABLE IF NOT EXISTS `pedidos_has_mesas` (
  `pedidos_idpedidos` int(11) NOT NULL,
  `mesas_idMesas` int(11) NOT NULL,
  PRIMARY KEY (`pedidos_idpedidos`,`mesas_idMesas`),
  KEY `fk_pedidos_has_mesas_mesas1_idx` (`mesas_idMesas`),
  KEY `fk_pedidos_has_mesas_pedidos1_idx` (`pedidos_idpedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pedidos_has_mesas`
--

INSERT INTO `pedidos_has_mesas` (`pedidos_idpedidos`, `mesas_idMesas`) VALUES
(14, 11),
(15, 11),
(16, 11),
(17, 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pratos`
--

CREATE TABLE IF NOT EXISTS `pratos` (
  `idPratos` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `preco` double(10,2) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `CategoriaPratos_idCategoriaPratos` int(11) NOT NULL,
  `ingredientes_Aux_codigo` int(11) DEFAULT NULL,
  `ingredientes_codigo` int(11) DEFAULT NULL,
  `ingredientesId` int(11) NOT NULL,
  PRIMARY KEY (`idPratos`),
  UNIQUE KEY `nome_UNIQUE` (`nome`),
  KEY `fk_Pratos_CategoriaPratos1_idx` (`CategoriaPratos_idCategoriaPratos`),
  KEY `fk_pratos_ingredientes_Aux1_idx` (`ingredientes_Aux_codigo`),
  KEY `fk_pratos_ingredientes1_idx` (`ingredientes_codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

--
-- Extraindo dados da tabela `pratos`
--

INSERT INTO `pratos` (`idPratos`, `nome`, `categoria`, `preco`, `descricao`, `CategoriaPratos_idCategoriaPratos`, `ingredientes_Aux_codigo`, `ingredientes_codigo`, `ingredientesId`) VALUES
(32, 'Pepsi', 'Bebidas', 35.00, NULL, 7, NULL, NULL, 0),
(33, 'Coca Cola', 'Bebidas', 35.00, NULL, 7, NULL, NULL, 0),
(34, 'Sprite', 'Bebidas', 35.00, NULL, 7, NULL, NULL, 0),
(35, 'Fanta', 'Bebidas', 35.00, NULL, 7, NULL, NULL, 0),
(39, 'Sparleta', 'Bebidas', 35.00, NULL, 7, NULL, NULL, 0),
(40, 'Blue', 'Bebidas', 40.00, NULL, 7, NULL, NULL, 0),
(41, 'Cream Soda', 'Bebidas', 35.00, NULL, 7, NULL, NULL, 0),
(44, 'Humburguer completo', 'Burguers', 105.00, 'aaa', 9, NULL, 142, 31),
(45, 'Salada de legumes', 'Saladas', 150.00, '', 5, NULL, 145, 32);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE IF NOT EXISTS `produtos` (
  `idProduto` int(11) NOT NULL AUTO_INCREMENT,
  `nomeProduto` varchar(255) NOT NULL,
  `quantidade` double NOT NULL,
  `quantMax` double NOT NULL,
  `quantMin` double NOT NULL,
  `codigoBarras` varchar(65) NOT NULL,
  `preco` double(10,2) NOT NULL,
  `necessidade` varchar(45) NOT NULL,
  `unidadeMedida` varchar(45) NOT NULL,
  `unidadeMedidaMax` varchar(45) NOT NULL,
  `unidadeMedidaMin` varchar(45) NOT NULL,
  `Fornecedores_idFornecedores` int(11) NOT NULL,
  `CategoriaProduto_idCategoriaProduto` int(11) NOT NULL,
  PRIMARY KEY (`idProduto`),
  UNIQUE KEY `codigoBarras_UNIQUE` (`codigoBarras`),
  UNIQUE KEY `nomeProduto_UNIQUE` (`nomeProduto`),
  KEY `fk_Produtos_Fornecedores1_idx` (`Fornecedores_idFornecedores`),
  KEY `fk_Produtos_CategoriaProduto1_idx` (`CategoriaProduto_idCategoriaProduto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`idProduto`, `nomeProduto`, `quantidade`, `quantMax`, `quantMin`, `codigoBarras`, `preco`, `necessidade`, `unidadeMedida`, `unidadeMedidaMax`, `unidadeMedidaMin`, `Fornecedores_idFornecedores`, `CategoriaProduto_idCategoriaProduto`) VALUES
(4, 'banana', 30, 500, 50, '1101214548', 15.00, 'Nao essencial', 'kg', 'kg', 'kg', 3, 4),
(6, 'ananas', 30, 500, 50, '044649865', 15.00, 'Essencial', 'kg', 'kg', 'kg', 3, 4),
(8, 'carne de vaca', 43, 200, 5, '48564584', 150.00, 'Essencial', 'kg', 'kg', 'kg', 5, 9),
(9, 'frango', 500, 10, 5, '789645', 140.00, 'Essencial', 'kg', 'T', 'T', 5, 9),
(10, 'ovos', 12, 500, 15, '6548645', 12.00, 'Essencial', 'favos', 'favos', 'favos', 5, 9),
(13, 'laranja', 80, 500, 50, '86546524', 20.00, 'Essencial', 'kg', 'kg', 'kg', 3, 4),
(14, 'cenoura', 100, 500, 50, '4654845', 15.00, 'Essencial', 'kg', 'kg', 'kg', 3, 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservas`
--

CREATE TABLE IF NOT EXISTS `reservas` (
  `idReservas` int(11) NOT NULL AUTO_INCREMENT,
  `nomeCliente` varchar(255) NOT NULL,
  `telefone` varchar(85) NOT NULL,
  `celular` varchar(45) NOT NULL,
  `tipoIdentificacao` varchar(45) NOT NULL,
  `numeroIdentificacao` varchar(45) NOT NULL,
  `data` date NOT NULL,
  `horarioInicial` varchar(45) NOT NULL,
  `horarioFinal` varchar(45) NOT NULL,
  `nrAcompanhantes` int(11) NOT NULL,
  `nrMesas` int(11) NOT NULL,
  `observacoes` varchar(255) DEFAULT NULL,
  `preco` double NOT NULL,
  `Cliente_idCliente` int(11) DEFAULT NULL,
  `estado` varchar(45) NOT NULL,
  PRIMARY KEY (`idReservas`),
  KEY `fk_Reservas_Cliente1_idx` (`Cliente_idCliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Extraindo dados da tabela `reservas`
--

INSERT INTO `reservas` (`idReservas`, `nomeCliente`, `telefone`, `celular`, `tipoIdentificacao`, `numeroIdentificacao`, `data`, `horarioInicial`, `horarioFinal`, `nrAcompanhantes`, `nrMesas`, `observacoes`, `preco`, `Cliente_idCliente`, `estado`) VALUES
(14, 'Frank Cumaio', '984651', '9846548', 'BI', '9846579645G', '2015-10-14', '11:00', '13:00', 7, 2, '', 1300, 2, 'confirmada'),
(15, 'Inercio Belton', '986456854', '8456854', 'BI', '865434984864h', '2015-10-08', '14:00', '15:00', 13, 3, '', 1500, NULL, 'canceladas'),
(16, 'Frank Cumaio', '984651', '9846548', 'BI', '9846579645G', '2015-10-12', '01:57', '02:00', 4, 1, '', 1200, 2, 'confirmada'),
(17, 'Inercio Belton', '7845', '789654', 'BI', '8645452f', '2015-10-21', '12:00', '14:00', 6, 1, '', 1500, 3, 'pendentes');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL,
  `Tipo` varchar(45) NOT NULL,
  `Funcionarios_idFuncionario` int(11) DEFAULT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `Funcionarios_idFuncionario_UNIQUE` (`Funcionarios_idFuncionario`),
  KEY `fk_Usuario_Funcionarios1_idx` (`Funcionarios_idFuncionario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`idUsuario`, `nome`, `senha`, `Tipo`, `Funcionarios_idFuncionario`) VALUES
(2, 'belton', '1234', 'Operador', 2),
(3, 'Inercio', '123', 'Gerente', 3),
(4, 'Bilito', '1234', '', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE IF NOT EXISTS `vendas` (
  `idVendas` int(11) NOT NULL AUTO_INCREMENT,
  `cliente` varchar(255) NOT NULL,
  `produto` varchar(45) NOT NULL,
  `quantidade` double NOT NULL,
  `preco` double NOT NULL,
  `FormasPagamento_idFormasPagamento` int(11) NOT NULL,
  `grupoVenda` int(11) DEFAULT NULL,
  `dataVenda` date DEFAULT NULL,
  PRIMARY KEY (`idVendas`),
  KEY `fk_Vendas_FormasPagamento1_idx` (`FormasPagamento_idFormasPagamento`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Extraindo dados da tabela `vendas`
--

INSERT INTO `vendas` (`idVendas`, `cliente`, `produto`, `quantidade`, `preco`, `FormasPagamento_idFormasPagamento`, `grupoVenda`, `dataVenda`) VALUES
(1, '', 'Sprite', 1, 1, 1, 1, '2015-10-11'),
(2, '', 'Fanta', 2, 2, 1, 1, '2015-10-11'),
(3, '', 'Salada de legume', 1, 20, 1, 2, '2015-10-11'),
(4, '', 'Sprite', 2, 40, 1, 2, '2015-10-11'),
(5, '', 'Coca cola', 1, 15, 1, 2, '2015-10-11'),
(6, '', 'Salada de frutas', 2, 120, 1, 3, '2015-10-12'),
(7, '', 'Coca Cola', 1, 35, 1, 3, '2015-10-12'),
(8, '', 'Sprite', 2, 70, 1, 3, '2015-10-12'),
(9, '', 'Fanta', 1, 35, 1, 3, '2015-10-12'),
(10, '', 'Salada de frutas', 2, 2, 1, 4, '2015-10-12'),
(11, '', 'Pepsi', 1, 1, 1, 4, '2015-10-12'),
(12, '', 'Sopa', 1, 1, 1, 5, '2015-10-14'),
(13, '', 'Salada de frutas', 2, 2, 1, 5, '2015-10-14'),
(14, '', 'Sparleta', 1, 35, 1, 6, '2015-10-17'),
(15, '', 'Blue', 1, 40, 1, 6, '2015-10-17'),
(16, '', 'Cream Soda', 1, 35, 1, 6, '2015-10-17'),
(17, '', 'Sprite', 1, 35, 1, 6, '2015-10-17');

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas_has_cliente`
--

CREATE TABLE IF NOT EXISTS `vendas_has_cliente` (
  `Vendas_idVendas` int(11) NOT NULL,
  `Cliente_idCliente` int(11) NOT NULL,
  PRIMARY KEY (`Vendas_idVendas`,`Cliente_idCliente`),
  KEY `fk_Vendas_has_Cliente_Cliente1_idx` (`Cliente_idCliente`),
  KEY `fk_Vendas_has_Cliente_Vendas1_idx` (`Vendas_idVendas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `fk_Cliente_Contacto1` FOREIGN KEY (`Contacto_idContacto`) REFERENCES `contacto` (`idContacto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Cliente_Identificacao1` FOREIGN KEY (`Identificacao_idIdentificacao`) REFERENCES `identificacao` (`idIdentificacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Cliente_Morada1` FOREIGN KEY (`Morada_idMorada`) REFERENCES `morada` (`idMorada`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `contacliente_has_cliente`
--
ALTER TABLE `contacliente_has_cliente`
  ADD CONSTRAINT `fk_contaCliente_has_cliente_cliente1` FOREIGN KEY (`cliente_idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_contaCliente_has_cliente_contaCliente1` FOREIGN KEY (`contaCliente_idcontaCliente`) REFERENCES `contacliente` (`idcontaCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  ADD CONSTRAINT `fk_Fornecedores_CategoriaProduto1` FOREIGN KEY (`CategoriaProduto_idCategoriaProduto`) REFERENCES `categoriaproduto` (`idCategoriaProduto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Fornecedores_Contacto1` FOREIGN KEY (`Contacto_idContacto`) REFERENCES `contacto` (`idContacto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Fornecedores_Morada1` FOREIGN KEY (`Morada_idMorada`) REFERENCES `morada` (`idMorada`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD CONSTRAINT `fk_Funcionarios_Contacto1` FOREIGN KEY (`Contacto_idContacto`) REFERENCES `contacto` (`idContacto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Funcionarios_Identificacao1` FOREIGN KEY (`Identificacao_idIdentificacao`) REFERENCES `identificacao` (`idIdentificacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Funcionarios_Morada1` FOREIGN KEY (`Morada_idMorada`) REFERENCES `morada` (`idMorada`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pedidos_has_mesas`
--
ALTER TABLE `pedidos_has_mesas`
  ADD CONSTRAINT `fk_pedidos_has_mesas_mesas1` FOREIGN KEY (`mesas_idMesas`) REFERENCES `mesas` (`idMesas`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pedidos_has_mesas_pedidos1` FOREIGN KEY (`pedidos_idpedidos`) REFERENCES `pedidos` (`idpedidos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pratos`
--
ALTER TABLE `pratos`
  ADD CONSTRAINT `fk_Pratos_CategoriaPratos1` FOREIGN KEY (`CategoriaPratos_idCategoriaPratos`) REFERENCES `categoriapratos` (`idCategoriaPratos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pratos_ingredientes1` FOREIGN KEY (`ingredientes_codigo`) REFERENCES `ingredientes` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pratos_ingredientes_Aux1` FOREIGN KEY (`ingredientes_Aux_codigo`) REFERENCES `ingredientes_aux` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `fk_Produtos_CategoriaProduto1` FOREIGN KEY (`CategoriaProduto_idCategoriaProduto`) REFERENCES `categoriaproduto` (`idCategoriaProduto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Produtos_Fornecedores1` FOREIGN KEY (`Fornecedores_idFornecedores`) REFERENCES `fornecedores` (`idFornecedores`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `fk_Reservas_Cliente1` FOREIGN KEY (`Cliente_idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_Usuario_Funcionarios1` FOREIGN KEY (`Funcionarios_idFuncionario`) REFERENCES `funcionarios` (`idFuncionario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `vendas`
--
ALTER TABLE `vendas`
  ADD CONSTRAINT `fk_Vendas_FormasPagamento1` FOREIGN KEY (`FormasPagamento_idFormasPagamento`) REFERENCES `formaspagamento` (`idFormasPagamento`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `vendas_has_cliente`
--
ALTER TABLE `vendas_has_cliente`
  ADD CONSTRAINT `fk_Vendas_has_Cliente_Cliente1` FOREIGN KEY (`Cliente_idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Vendas_has_Cliente_Vendas1` FOREIGN KEY (`Vendas_idVendas`) REFERENCES `vendas` (`idVendas`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
